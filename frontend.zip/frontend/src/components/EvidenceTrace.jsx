import StatusBadge from "./StatusBadge";

function buildCards(criteria = [], depth = 0) {
  const cards = [];
  for (const c of criteria) {
    if (c.logic) {
      cards.push({ isGroup: true, label: `${c.logic} group`, depth });
      cards.push(...buildCards(c.criteria, depth + 1));
      continue;
    }

    const pass = c.passed;
    let label = "", value = "";

    if (c.op === "age_in_range") {
      label = "Age";
      value = `${c.age} yrs  ·  range ${c.range?.[0]}–${c.range?.[1]}`;
    } else if (c.op === "gender") {
      label = "Gender";
      value = c.member_gender === "F" ? "Female" : "Male";
    } else if (c.op === "continuous_enrollment") {
      label = "Enrollment";
      value = `${c.gap_days}d gap  ·  limit ${c.allowable_gap_days}d`;
    } else if (c.op === "has_code") {
      label = c.value_set;
      value = pass && c.matches?.length
        ? c.matches.map(m => `${m.code_system} ${m.code}  ${m.date}`).join("  ·  ")
        : "No qualifying code found";
    } else if (c.op === "value_compare") {
      label = c.field;
      if (c.reason === "no readings in window") {
        value = "No reading found";
      } else if (c.evaluated?.length) {
        const last = c.evaluated[c.evaluated.length - 1];
        value = `${last.value}  ·  ${last.date}  ·  target ${c.comparator} ${c.threshold}`;
      }
    } else if (c.op === "med_active") {
      label = c.value_set;
      value = pass && c.matches?.length
        ? c.matches.map(m => `${m.code} ${m.date}`).join("  ·  ")
        : "No active medication";
    } else {
      label = c.op; value = "";
    }

    cards.push({ pass, label, value, depth });
  }
  return cards;
}

function Section({ title, ev }) {
  if (!ev?.criteria?.length) return null;
  const cards = buildCards(ev.criteria);
  return (
    <div className="etc-section">
      <div className="etc-section-title">{title}</div>
      <div className="etc-grid">
        {cards.map((c, i) =>
          c.isGroup ? (
            <div key={i} className="etc-group-label" style={{ marginLeft: c.depth * 12 }}>
              {c.label}
            </div>
          ) : (
            <div key={i} className={`etc-card ${c.pass ? "etc-pass" : "etc-fail"}`}
              style={{ marginLeft: c.depth * 12 }}>
              <div className="etc-card-label">{c.label}</div>
              <div className="etc-card-value">{c.value}</div>
            </div>
          )
        )}
      </div>
    </div>
  );
}

export default function EvidenceTrace({ trace }) {
  if (!trace) return null;
  const ev = trace.evidence || {};
  return (
    <div className="etc-wrap">
      <div className="etc-header">
        <strong className="etc-id">{trace.member_id} · {trace.measure_id}</strong>
        <StatusBadge status={trace.status} />
      </div>
      <Section title="Eligibility"  ev={ev.eligibility} />
      <Section title="Exclusions"   ev={ev.exclusions}  />
      <Section title="Numerator"    ev={ev.numerator}   />
      {trace.open_gap && (
        <div className="etc-open-gap">Open gap: {trace.open_gap.join(" · ")}</div>
      )}
    </div>
  );
}
