const BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";

async function get(path) {
  const r = await fetch(`${BASE}${path}`);
  if (!r.ok) throw new Error(`${path} -> ${r.status}`);
  return r.json();
}
async function post(path, body) {
  const r = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return r.json();
}

export const api = {
  measures: () => get("/measures"),
  members: () => get("/members"),
  gapsByMeasure: (id) => get(`/gaps/measure/${id}`),
  gapsByMember: (id) => get(`/gaps/member/${id}`),
  openGaps: () => get("/gaps/open"),
  memberProfile: (id) => get(`/member/${id}/profile`),
  evidence: (member, measure) => get(`/member/${member}/evidence/${measure}`),
  listSpecs:     ()           => get("/specs"),
  executeSpec:   (payload)    => post("/specs/execute",      payload),
  goldenTest:    (payload)    => post("/specs/golden-test",  payload),
  getSpec:      (id)    => get(`/specs/${id}`),
  validateSpec: (config) => post("/specs/validate", { config }),
  uploadSpec:   (config) => post("/specs/upload",   { config }),
};
