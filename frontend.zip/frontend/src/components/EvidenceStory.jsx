/**
 * EvidenceStory — narrates the gap detection run as a plain-English story.
 * Input: the same `trace` object used by EvidenceTrace.
 */

function step(n, title, passed, lines) {
  return { n, title, passed, lines };
}

function buildStory(trace) {
  const ev     = trace.evidence || {};
  const elig   = ev.eligibility;
  const excl   = ev.exclusions;
  const num    = ev.numerator;
  const status = trace.status;
  const mid    = trace.measure_id;
  const mem    = trace.member_id;
  const steps  = [];

  /* ── Step 1: Eligibility ─────────────────────────────────────── */
  if (elig) {
    const criteria = elig.criteria || [];
    const lines = [];

    for (const c of criteria) {
      if (c.op === "age_in_range") {
        lines.push(c.passed
          ? `Age ${c.age} falls within the eligible range of ${c.range?.[0]}–${c.range?.[1]}.`
          : `Age ${c.age} is outside the eligible range of ${c.range?.[0]}–${c.range?.[1]}.`
        );
      } else if (c.op === "gender") {
        const g = c.member_gender === "F" ? "female" : "male";
        lines.push(c.passed
          ? `Member is ${g}, which meets the gender requirement.`
          : `Member is ${g}, which does not meet the gender requirement.`
        );
      } else if (c.op === "continuous_enrollment") {
        lines.push(c.passed
          ? `Enrollment gap was ${c.gap_days} day(s) — within the ${c.allowable_gap_days}-day allowable gap.`
          : `Enrollment gap was ${c.gap_days} day(s), exceeding the ${c.allowable_gap_days}-day limit.`
        );
      } else if (c.op === "has_code") {
        const found = c.matches?.length
          ? c.matches.map(m => `${m.code_system} ${m.code} on ${m.date}`).join(", ")
          : null;
        lines.push(c.passed
          ? `${c.value_set} diagnosis/event found (${found}).`
          : `No ${c.value_set} event found in the required window.`
        );
      }
    }

    if (!elig.passed) {
      lines.push(`Since ${mem} does not meet eligibility, they are not included in the ${mid} measure population.`);
    }

    steps.push(step(1, "Eligibility Check", elig.passed, lines));
  }

  if (status === "NOT_IN_POPULATION") {
    steps.push(step(null, "Outcome", false,
      [`${mem} is not in the eligible population for ${mid}. No further evaluation required.`]
    ));
    return steps;
  }

  /* ── Step 2: Exclusions ──────────────────────────────────────── */
  if (excl) {
    const lines = [];
    const hits  = [];
    const checked = [];

    for (const c of flatten(excl.criteria || [])) {
      if (c.op === "has_code") {
        if (c.passed && c.matches?.length) {
          hits.push(`${c.value_set} (${c.matches.map(m => `${m.code_system} ${m.code} · ${m.date}`).join(", ")})`);
        } else {
          checked.push(c.value_set);
        }
      }
    }

    if (hits.length) {
      lines.push(`Exclusion criteria met: ${hits.join("; ")}.`);
      lines.push(`${mem} is excluded from the ${mid} measure.`);
    } else {
      lines.push(`No exclusion criteria were met.`);
      if (checked.length) {
        lines.push(`Checked: ${checked.join(", ")} — none found.`);
      }
      lines.push(`${mem} remains in the denominator.`);
    }

    steps.push(step(2, "Exclusion Check", !excl.passed, lines));
  }

  if (status === "EXCLUDED") {
    steps.push(step(null, "Outcome", false,
      [`${mem} has been excluded from the ${mid} measure population.`]
    ));
    return steps;
  }

  /* ── Step 3: Numerator ───────────────────────────────────────── */
  if (num) {
    const lines = [];

    for (const c of flatten(num.criteria || [])) {
      if (c.op === "has_code") {
        if (c.passed && c.matches?.length) {
          const codes = c.matches.map(m => `${m.code_system} ${m.code} on ${m.date}`).join(", ");
          const win   = (c.window || "").replace(/_/g, " ");
          lines.push(`${c.value_set} found: ${codes}.`);
          lines.push(`This qualifies within the window (${win}).`);
        } else if (!c.passed) {
          const win = (c.window || "").replace(/_/g, " ");
          lines.push(`No ${c.value_set} code found within the required window (${win}).`);
        }
      } else if (c.op === "value_compare") {
        if (c.evaluated?.length) {
          const last = c.evaluated[c.evaluated.length - 1];
          lines.push(c.passed
            ? `${c.field} reading was ${last.value} on ${last.date} — meets target (${c.comparator} ${c.threshold}).`
            : `${c.field} reading was ${last.value} on ${last.date} — does not meet target (${c.comparator} ${c.threshold}).`
          );
        } else {
          lines.push(`No ${c.field} reading found in the measurement period.`);
        }
      }
    }

    steps.push(step(3, "Numerator Check", num.passed, lines));
  }

  /* ── Outcome ─────────────────────────────────────────────────── */
  if (status === "COMPLIANT") {
    steps.push(step(null, "Outcome", true,
      [`${mem} has met the requirements for ${mid}.`,
       trace.open_gap ? "" : "No care gaps identified."]
    ));
  } else if (status === "NON_COMPLIANT") {
    const gap = trace.open_gap ? trace.open_gap.join("; ") : "Numerator not met";
    steps.push(step(null, "Outcome", false,
      [`${mem} has an open care gap for ${mid}.`,
       `Action required: ${gap}.`]
    ));
  }

  return steps;
}

/* walk nested criteria groups and return a flat list */
function flatten(criteria) {
  const out = [];
  for (const c of criteria) {
    if (c.criteria) out.push(...flatten(c.criteria));
    else out.push(c);
  }
  return out;
}

export default function EvidenceStory({ trace }) {
  if (!trace) return null;
  const steps = buildStory(trace);

  return (
    <div className="story-wrap">
      <div className="story-header">
        <span className="story-member">{trace.member_id}</span>
        <span className="story-sep">·</span>
        <span className="story-measure">{trace.measure_id}</span>
      </div>

      <div className="story-steps">
        {steps.map((s, i) => (
          <div key={i} className={`story-step ${s.n ? "" : "story-outcome"} ${s.passed ? "story-pass" : "story-fail"}`}>
            {s.n && (
              <div className="story-step-num">Step {s.n}</div>
            )}
            <div className="story-step-title">{s.title}</div>
            <div className="story-step-body">
              {s.lines.filter(Boolean).map((line, j) => (
                <p key={j} className="story-line">{line}</p>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
