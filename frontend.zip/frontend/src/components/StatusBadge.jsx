const STYLES = {
  COMPLIANT:         { fg: "var(--ink)", dot: "#16a34a", label: "Compliant"     },
  NON_COMPLIANT:     { fg: "var(--ink)", dot: "#dc2626", label: "Non-Compliant" },
  EXCLUDED:          { fg: "var(--ink)", dot: "#94a3b8", label: "Excluded"      },
  NOT_IN_POPULATION: { fg: "var(--ink)", dot: "#cbd5e1", label: "Not in Pop"    },
};

export default function StatusBadge({ status }) {
  const s = STYLES[status] || STYLES.NOT_IN_POPULATION;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      color: s.fg, fontWeight: 600, fontSize: 12,
      fontFamily: "var(--sans)", whiteSpace: "nowrap",
    }}>
      <span style={{
        width: 7, height: 7, borderRadius: "50%",
        background: s.dot, flexShrink: 0,
      }} />
      {s.label}
    </span>
  );
}
