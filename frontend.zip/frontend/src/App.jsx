import { useEffect, useState, Fragment } from "react";
import { api } from "./api";
import StatusBadge from "./components/StatusBadge";
import EvidenceTrace from "./components/EvidenceTrace";
import EvidenceStory from "./components/EvidenceStory";

const TABS = ["Dashboard", "By Measure", "By Member", "Spec Manager"];

export default function App() {
  const [tab, setTab] = useState("Dashboard");
  const [measures, setMeasures] = useState([]);

  const refresh = () => api.measures().then(setMeasures).catch(() => {});
  useEffect(() => { refresh(); }, []);

  return (
    <div className="app">
      <header>
        <div className="brand">
          <div className="logo">
            <span className="logo-text">EXL</span>
          </div>
          <div>
            <h1>Gap Detection Engine</h1>
            <p>Spec-driven · deterministic · auditable</p>
          </div>
        </div>
        <nav>
          {TABS.map((t) => (
            <button key={t} className={tab === t ? "on" : ""} onClick={() => setTab(t)}>
              {t}
            </button>
          ))}
        </nav>
      </header>

      <main>
        {tab === "Dashboard" && <Dashboard measures={measures} />}
        {tab === "By Measure" && <ByMeasure measures={measures} />}
        {tab === "By Member" && <ByMember />}
        {tab === "Spec Manager" && <SpecManager onDone={refresh} />}
      </main>
    </div>
  );
}

/* ---------------------------------------------------------------- Dashboard */
function Dashboard({ measures }) {
  return (
    <>
      <h2>Population Overview</h2>
      <table className="dash-table">
        <thead>
          <tr>
            <th>Measure ID</th>
            <th>Measure Name</th>
            <th>Total Eligible</th>
            <th>Compliant</th>
            <th>Non-Compliant</th>
            <th>Excluded</th>
            <th>Compliance Rate</th>
            <th style={{ minWidth: 140 }}>Progress</th>
          </tr>
        </thead>
        <tbody>
          {measures.map((m) => (
            <tr key={m.measure_id}>
              <td><span className="mono mid">{m.measure_id}</span></td>
              <td>{m.measure_name}</td>
              <td className="dash-num">{m.eligible_population}</td>
              <td className="dash-num dash-g">{m.compliant}</td>
              <td className="dash-num dash-r">{m.non_compliant}</td>
              <td className="dash-num dash-x">{m.excluded}</td>
              <td className="dash-num"><b>{m.compliance_rate}%</b></td>
              <td>
                <div className="dash-bar">
                  <div className="dash-bar-fill" style={{ width: `${m.compliance_rate}%` }} />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}

/* -------------------------------------------------------------- By Measure */
const PAGE_SIZE = 10;

function MeasureBlock({ meta }) {
  const [rows, setRows]         = useState([]);
  const [trace, setTrace]       = useState(null);
  const [traceRow, setTraceRow] = useState(null);
  const [page, setPage]         = useState(1);
  const [statusFilter, setStatusFilter] = useState("ALL");

  useEffect(() => {
    api.gapsByMeasure(meta.measure_id).then(r => { setRows(r); setPage(1); setStatusFilter("ALL"); });
  }, [meta.measure_id]);

  const toggleTrace = (r) => {
    if (traceRow === r.member_id) { setTrace(null); setTraceRow(null); return; }
    setTraceRow(r.member_id);
    api.evidence(r.member_id, r.measure_id).then(setTrace);
  };

  const compliant    = rows.filter(r => r.status === "COMPLIANT").length;
  const nonCompliant = rows.filter(r => r.status === "NON_COMPLIANT").length;
  const excluded     = rows.filter(r => r.status === "EXCLUDED").length;

  const filteredRows = statusFilter === "ALL" ? rows : rows.filter(r => r.status === statusFilter);
  const totalPages   = Math.max(1, Math.ceil(filteredRows.length / PAGE_SIZE));
  const pageRows     = filteredRows.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  return (
    <div className="bm-block">
      {/* segment 1 — summary */}
      <div className="bm-summary">
        <div className="bm-sum-title">
          <span className="mono mid">{meta.measure_id}</span>
          <span className="bm-mfull">{meta.measure_name}</span>
        </div>
        <div className="bm-stats-row">
          {[
            { label: "Total Population", value: meta.eligible_population, cls: ""          },
            { label: "Compliant",        value: compliant,                cls: "bm-g"      },
            { label: "Non-Compliant",    value: nonCompliant,             cls: "bm-r"      },
            { label: "Excluded",         value: excluded,                 cls: "bm-x"      },
            { label: "Compliance Rate",  value: `${meta.compliance_rate}%`, cls: "bm-rate" },
          ].map(({ label, value, cls }) => (
            <div className="bm-stat" key={label}>
              <div className={`bm-stat-val ${cls}`}>{value}</div>
              <div className="bm-stat-label">{label}</div>
            </div>
          ))}
          <div className="bm-stat bm-stat-bar">
            <div className="bar" style={{ marginBottom: 6 }}>
              <div className="bar-fill" style={{ width: `${meta.compliance_rate}%` }} />
            </div>
            <div className="bm-stat-label">Compliance Progress</div>
          </div>
        </div>
      </div>

      {/* segment 2 — member detail */}
      <div className="bm-detail-header">
        <div className="bm-detail-title">Member Detail</div>
        <div className="bm-filter-row">
          <label className="bm-filter-label">Status</label>
          <select className="bm-filter-select"
            value={statusFilter}
            onChange={e => { setStatusFilter(e.target.value); setPage(1); setTrace(null); setTraceRow(null); }}>
            <option value="ALL">All ({rows.length})</option>
            <option value="COMPLIANT">Compliant ({compliant})</option>
            <option value="NON_COMPLIANT">Non-Compliant ({nonCompliant})</option>
            <option value="EXCLUDED">Excluded ({excluded})</option>
          </select>
        </div>
      </div>
      <table>
        <thead>
          <tr><th>Member ID</th><th>Status</th><th>Open Gap</th><th>Evidence</th></tr>
        </thead>
        <tbody>
          {pageRows.map(r => (
            <>
              <tr key={r.member_id}>
                <td className="mono">{r.member_id}</td>
                <td><StatusBadge status={r.status} /></td>
                <td className="gap">{r.open_gap ? r.open_gap.join(" · ") : "—"}</td>
                <td>
                  <button className="link" onClick={() => toggleTrace(r)}>
                    {traceRow === r.member_id ? "hide ▲" : "show ▼"}
                  </button>
                </td>
              </tr>
              {traceRow === r.member_id && trace && (
                <tr key={r.member_id + "_t"}>
                  <td colSpan={4} className="mp-trace-cell">
                    <EvidenceTrace trace={trace} />
                  </td>
                </tr>
              )}
            </>
          ))}
        </tbody>
      </table>

      {/* pagination */}
      <div className="pg-bar">
        <span className="pg-info">
          {filteredRows.length === 0 ? "No records" : `${(page - 1) * PAGE_SIZE + 1}–${Math.min(page * PAGE_SIZE, filteredRows.length)} of ${filteredRows.length}`}
        </span>
        <div className="pg-controls">
          <button className="pg-btn" onClick={() => setPage(1)}        disabled={page === 1}>«</button>
          <button className="pg-btn" onClick={() => setPage(p => p - 1)} disabled={page === 1}>‹</button>
          {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
            <button key={p} className={`pg-btn ${p === page ? "pg-active" : ""}`}
              onClick={() => setPage(p)}>{p}</button>
          ))}
          <button className="pg-btn" onClick={() => setPage(p => p + 1)} disabled={page === totalPages}>›</button>
          <button className="pg-btn" onClick={() => setPage(totalPages)}  disabled={page === totalPages}>»</button>
        </div>
      </div>
    </div>
  );
}

function ByMeasure({ measures }) {
  const [search, setSearch] = useState("");
  const [sel, setSel]       = useState(null);
  const [open, setOpen]     = useState(false);

  useEffect(() => {
    if (measures.length && !sel) setSel(measures[0].measure_id);
  }, [measures]);

  const filtered = measures.filter(m =>
    m.measure_id.toLowerCase().includes(search.toLowerCase()) ||
    m.measure_name.toLowerCase().includes(search.toLowerCase())
  );

  const selMeta = measures.find(m => m.measure_id === sel);

  const pick = (id) => { setSel(id); setSearch(""); setOpen(false); };

  return (
    <>
      <div className="bm-search-row">
        <div className="bm-search-wrap">
          <input className="bm-search"
            value={search}
            onChange={e => { setSearch(e.target.value); setOpen(true); }}
            onFocus={() => setOpen(true)}
            placeholder={selMeta ? `${selMeta.measure_id} — ${selMeta.measure_name}` : "Select a measure…"}
          />
          {open && (
            <div className="bm-dropdown">
              {filtered.map(m => (
                <div key={m.measure_id}
                  className={`bm-drop-item ${sel === m.measure_id ? "active" : ""}`}
                  onMouseDown={() => pick(m.measure_id)}>
                  <span className="mono">{m.measure_id}</span>
                  <span className="bm-drop-name">{m.measure_name}</span>
                </div>
              ))}
              {filtered.length === 0 && <div className="bm-drop-empty">No measures match</div>}
            </div>
          )}
        </div>
      </div>

      {selMeta && (
        <div onClickCapture={() => open && setOpen(false)}>
          <MeasureBlock key={sel} meta={selMeta} />
        </div>
      )}
    </>
  );
}

/* ── helper: pull matching codes out of a numerator evidence tree ── */
function extractMatches(criteria = []) {
  const out = [];
  for (const c of criteria) {
    if (c.matches?.length) {
      c.matches.forEach(m => out.push({ ...m, value_set: c.value_set }));
    }
    if (c.criteria) out.push(...extractMatches(c.criteria));
  }
  return out;
}

/* --------------------------------------------------------------- By Member */
function ByMember() {
  const [query, setQuery]           = useState("");
  const [members, setMembers]       = useState([]);
  const [profile, setProfile]       = useState(null);
  const [gaps, setGaps]             = useState([]);
  const [evidenceMap, setEvidenceMap] = useState({});
  const [trace, setTrace]           = useState(null);
  const [traceMid, setTraceMid]     = useState(null);
  const [traceView, setTraceView]   = useState("cards"); // "cards" | "story"
  const [notFound, setNotFound]     = useState(false);

  useEffect(() => { api.members().then(setMembers); }, []);

  const suggestions = query.length >= 2
    ? members.filter(m => m.member_id.toLowerCase().includes(query.toLowerCase())).slice(0, 6)
    : [];

  const load = async (id) => {
    setProfile(null); setGaps([]); setEvidenceMap({});
    setTrace(null); setTraceMid(null); setNotFound(false);
    try {
      const [prof, g] = await Promise.all([api.memberProfile(id), api.gapsByMember(id)]);
      setProfile(prof); setGaps(g);
      // auto-fetch evidence for every measure in parallel
      const entries = await Promise.all(
        g.map(r => api.evidence(id, r.measure_id)
          .then(t => [r.measure_id, extractMatches(t.numerator?.criteria)])
          .catch(() => [r.measure_id, []]))
      );
      setEvidenceMap(Object.fromEntries(entries));
    } catch { setNotFound(true); }
  };

  const search = () => { const id = query.trim(); if (id) load(id); };

  const pickEvidence = (measureId) => {
    if (traceMid === measureId) { setTrace(null); setTraceMid(null); return; }
    setTraceMid(measureId);
    api.evidence(profile.member_id, measureId).then(setTrace);
  };

  const switchView = (v) => setTraceView(v);

  return (
    <div className="mp">
      <h2>Member 360°</h2>

      {/* ── search ── */}
      <div className="mp-search">
        <div className="mp-input-wrap">
          <input
            className="mp-input"
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === "Enter" && search()}
            placeholder="Search by Member ID (e.g. M001)…"
          />
          <button className="mp-btn" onClick={search}>Search</button>
        </div>
        {suggestions.length > 0 && !profile && (
          <div className="mp-suggest">
            {suggestions.map(m => (
              <div key={m.member_id} className="mp-suggest-item"
                onClick={() => { setQuery(m.member_id); load(m.member_id); }}>
                <span className="mono">{m.member_id}</span>
                <span className="mp-s-meta">{m.gender === "F" ? "Female" : "Male"} · DOB {m.dob}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {notFound && <p className="mp-error">Member not found. Check the ID and try again.</p>}

      {profile && (
        <>
          {/* ── demographics ── */}
          <div className="mp-section-title">Demographics</div>
          <div className="mp-demo-grid">
            {[
              ["Member ID",        profile.member_id],
              ["Age",              profile.age + " yrs"],
              ["Gender",           profile.gender === "F" ? "Female" : "Male"],
              ["Payer / Product",  profile.payer],
              ["Enrollment Status",profile.enrollment_status],
              ["PCP",              profile.pcp_name],
              ["Last Updated",     profile.last_updated],
            ].map(([label, val]) => (
              <div className="mp-demo-card" key={label}>
                <div className="mp-demo-label">{label}</div>
                <div className="mp-demo-val">{val}</div>
              </div>
            ))}
          </div>

          {/* ── gap info ── */}
          <div className="mp-section-title">Care Gaps</div>
          <div className="mp-gaps">
            <table>
              <thead>
                <tr><th>Measure</th><th>Status</th><th>Open Gap</th><th>Clinical Evidence</th><th>Criteria</th></tr>
              </thead>
              <tbody>
                {gaps.map(r => {
                  const matches = evidenceMap[r.measure_id] || [];
                  return (
                    <>
                      <tr key={r.measure_id}>
                        <td>
                          <span className="mono">{r.measure_id}</span>
                          <span className="mp-mname">{r.measure_name}</span>
                        </td>
                        <td><StatusBadge status={r.status} /></td>
                        <td className="gap">{r.open_gap ? r.open_gap.join(" · ") : "—"}</td>
                        <td className="mp-evidence-cell">
                          {matches.length > 0 ? (
                            <div className="mp-ev-list">
                              {matches.map((m, i) => (
                                <div className="mp-ev-item" key={i}>
                                  <span className="mp-ev-code">{m.code_system} {m.code}</span>
                                  <span className="mp-ev-vs">{m.value_set}</span>
                                  <span className="mp-ev-date">{m.date}</span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <span className="mp-ev-none">
                              {r.status === "NON_COMPLIANT" ? "No qualifying event found" : "—"}
                            </span>
                          )}
                        </td>
                        <td>
                          <button className="link" onClick={() => pickEvidence(r.measure_id)}>
                            {traceMid === r.measure_id ? "hide ▲" : "show ▼"}
                          </button>
                        </td>
                      </tr>
                      {traceMid === r.measure_id && trace && (
                        <tr key={r.measure_id + "_trace"}>
                          <td colSpan={5} className="mp-trace-cell">
                            <div className="trace-view-toggle">
                              <button className={traceView === "cards" ? "tv-on" : ""} onClick={() => switchView("cards")}>Criteria</button>
                              <button className={traceView === "story" ? "tv-on" : ""} onClick={() => switchView("story")}>Story</button>
                            </div>
                            {traceView === "cards"
                              ? <EvidenceTrace trace={trace} />
                              : <EvidenceStory trace={trace} />
                            }
                          </td>
                        </tr>
                      )}
                    </>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

/* -------------------------------------------------------------- Spec Review */
const NEW_TEMPLATE = `{
  "measure_id":   "XYZ",
  "measure_name": "...",
  "version":      "MY2025",
  "measure_type": "proportion",
  "measurement_period": { "start": "2025-01-01", "end": "2025-12-31" },

  "eligibility": {
    "operator": "AND",
    "criteria": [
      { "op": "age_in_range", "min": 18, "max": 75, "as_of": "period_end" },
      { "op": "continuous_enrollment", "lookback_months": 12, "allowable_gap_days": 45 }
    ]
  },

  "exclusions": {
    "operator": "OR",
    "criteria": [
      { "op": "has_code", "value_set": "...", "domain": "diagnoses", "window": "anytime" },
      {
        "operator": "AND",
        "criteria": [
          { "op": "has_code", "value_set": "...", "domain": "procedures", "window": "period" },
          { "op": "has_code", "value_set": "...", "domain": "diagnoses",  "window": "period" }
        ]
      }
    ]
  },

  "numerator": {
    "operator": "OR",
    "criteria": [
      { "op": "has_code", "value_set": "...", "domain": "procedures", "window": "period" }
    ]
  }
}`;

/* ------------------------------------------------------------ Spec Manager */
/* ── Population Flow Funnel ────────────────────────────────────────── */
function PopulationFlow({ summary }) {
  if (!summary) return null;
  const { scope_size, eligible_population, excluded, compliant, non_compliant } = summary;
  const not_in_pop = (scope_size || 0) - (eligible_population || 0);

  const boxes = [
    { label: "Evaluated",      value: scope_size,          cls: "pf-box-neutral" },
    { label: "Eligible",       value: eligible_population, cls: "pf-box-navy"    },
    { label: "Not Excluded",   value: (eligible_population - excluded), cls: "pf-box-navy" },
    { label: "Compliant",      value: compliant,           cls: "pf-box-green"   },
  ];
  const drops = [
    { label: "Not in Population", value: not_in_pop,   cls: "pf-drop-grey"  },
    { label: "Excluded",          value: excluded,      cls: "pf-drop-amber" },
    { label: "Non-Compliant",     value: non_compliant, cls: "pf-drop-red"   },
  ];

  return (
    <div className="pf-wrap">
      <div className="pf-section-title">Population Flow</div>
      <div className="pf-pipeline">
        {boxes.map((b, i) => (
          <>
            <div key={b.label} className={`pf-box ${b.cls}`}>
              <div className="pf-box-val">{b.value ?? 0}</div>
              <div className="pf-box-label">{b.label}</div>
              {drops[i] && (
                <div className={`pf-drop ${drops[i].cls}`}>
                  ↓ {drops[i].value ?? 0} {drops[i].label}
                </div>
              )}
            </div>
            {i < boxes.length - 1 && <div className="pf-arrow">→</div>}
          </>
        ))}
      </div>
      <div className="pf-rate">
        Compliance Rate: <strong>{summary.compliance_rate}%</strong>
        &nbsp;({compliant} / {eligible_population} eligible)
      </div>
    </div>
  );
}

/* ── Execution Results Table ───────────────────────────────────────── */
function ExecResults({ results, summary }) {
  const [open, setOpen] = useState(null);
  const [view, setView] = useState("operators");

  if (!results?.length) return null;

  const toggle = (id) => setOpen(o => o === id ? null : id);

  return (
    <div className="exec-results">
      {summary && (
        <div className="exec-summary-bar">
          {[
            { label: "Evaluated",     value: summary.scope_size,          cls: "" },
            { label: "Eligible",      value: summary.eligible_population, cls: "" },
            { label: "Compliant",     value: summary.compliant,           cls: "esb-g" },
            { label: "Non-Compliant", value: summary.non_compliant,       cls: "esb-r" },
            { label: "Excluded",      value: summary.excluded,            cls: "esb-x" },
            { label: "Rate",          value: summary.compliance_rate + "%", cls: "esb-rate" },
          ].map(s => (
            <div key={s.label} className="esb-item">
              <span className={`esb-val ${s.cls}`}>{s.value ?? 0}</span>
              <span className="esb-label">{s.label}</span>
            </div>
          ))}
        </div>
      )}
      <table>
        <thead>
          <tr>
            <th>Member</th><th>Status</th><th>Open Gap</th>
            <th>Eligibility</th><th>Exclusions</th><th>Numerator</th>
            <th>Detail</th>
          </tr>
        </thead>
        <tbody>
          {results.map(r => {
            const elig = r.stages?.eligibility;
            const excl = r.stages?.exclusions;
            const num  = r.stages?.numerator;
            return (
              <Fragment key={r.member_id}>
                <tr>
                  <td className="mono">{r.member_id}</td>
                  <td><StatusBadge status={r.status} /></td>
                  <td className="gap">{r.open_gap ? r.open_gap.join(" · ") : "—"}</td>
                  <td><StageChip passed={elig?.passed}          label={elig?.passed ? "Pass" : "Fail"} /></td>
                  <td><StageChip passed={excl && !excl.passed}  label={excl?.passed ? "Excluded" : "Clear"} invert /></td>
                  <td><StageChip passed={num?.passed}           label={num?.passed ? "Met" : "Not Met"} /></td>
                  <td>
                    <button className="link" onClick={() => toggle(r.member_id)}>
                      {open === r.member_id ? "hide ▲" : "show ▼"}
                    </button>
                  </td>
                </tr>
                {open === r.member_id && (
                  <tr>
                    <td colSpan={7} className="mp-trace-cell">
                      <div className="trace-view-toggle" style={{ marginBottom: 12 }}>
                        <button className={view === "operators" ? "tv-on" : ""} onClick={() => setView("operators")}>Operators</button>
                        <button className={view === "story"     ? "tv-on" : ""} onClick={() => setView("story")}>Story</button>
                      </div>
                      {view === "operators"
                        ? <StageOperators stages={r.stages} />
                        : <EvidenceStory trace={{
                            member_id: r.member_id, measure_id: "spec",
                            status: r.status, open_gap: r.open_gap,
                            evidence: buildTraceFromStages(r.stages)
                          }} />
                      }
                    </td>
                  </tr>
                )}
              </Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function StageChip({ passed, label, invert }) {
  const ok = invert ? !passed : passed;
  return (
    <span style={{
      fontSize: 11, fontWeight: 600, padding: "2px 8px", borderRadius: 3,
      background: ok ? "rgba(26,122,74,.1)" : "rgba(192,57,43,.08)",
      color: ok ? "var(--green)" : "var(--red)",
      borderLeft: `3px solid ${ok ? "var(--green)" : "var(--red)"}`,
    }}>{label}</span>
  );
}

function StageOperators({ stages }) {
  const sections = [
    ["ELIGIBILITY", stages?.eligibility],
    ["EXCLUSIONS",  stages?.exclusions],
    ["NUMERATOR",   stages?.numerator],
  ];
  return (
    <div className="so-wrap">
      {sections.map(([title, ev]) => ev && (
        <div key={title} className="so-section">
          <div className="so-title">{title}</div>
          <table className="so-table">
            <thead><tr><th>Operator</th><th>Result</th><th>Finding</th></tr></thead>
            <tbody>
              {(ev.criteria || []).map((c, i) => (
                <Fragment key={i}>
                  <tr className={c.passed ? "so-pass" : "so-fail"}>
                    <td style={{ paddingLeft: 12 }}>{c.op || "group"}</td>
                    <td><StageChip passed={c.passed} label={c.passed ? "Pass" : "Fail"} /></td>
                    <td className="so-label">{c.label}</td>
                  </tr>
                  {(c.children || []).map((cc, j) => (
                    <tr key={j} className={cc.passed ? "so-pass" : "so-fail"}>
                      <td style={{ paddingLeft: 28, color: "var(--muted)", fontSize: 11 }}>{cc.op}</td>
                      <td><StageChip passed={cc.passed} label={cc.passed ? "Pass" : "Fail"} /></td>
                      <td className="so-label">{cc.label}</td>
                    </tr>
                  ))}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
}

function buildTraceFromStages(stages) {
  const toGroup = (s) => {
    if (!s) return null;
    return {
      passed: s.passed,
      criteria: (s.criteria || []).map(c => ({
        op: c.op, passed: c.passed,
        value_set: c.label?.split(":")[0],
        matches: c.matches || [],
        evaluated: c.evaluated || [],
        gap_days: c.gap_days,
        age: c.age,
        range: c.label?.match(/\[(\d+)–(\d+)\]/)
          ? [c.label.match(/\[(\d+)–(\d+)\]/)[1], c.label.match(/\[(\d+)–(\d+)\]/)[2]]
          : null,
        comparator: c.label?.split(" ")[1],
        threshold:  c.label?.split(" ")[2],
        field: c.label?.split(" ")[0],
        window: c.label?.match(/\(([^)]+)\)/)?.[1],
        criteria: c.children,
        min_count: 1,
      }))
    };
  };
  return {
    eligibility: toGroup(stages?.eligibility),
    exclusions:  toGroup(stages?.exclusions),
    numerator:   toGroup(stages?.numerator),
  };
}

/* ── Execution Loader ──────────────────────────────────────────────── */
const LOADER_STEPS = [
  "Loading member profiles…",
  "Adapting spec config…",
  "Evaluating eligibility criteria…",
  "Checking exclusion rules…",
  "Running numerator logic…",
  "Collecting evidence traces…",
  "Calculating compliance rates…",
  "Preparing results…",
];

function ExecLoader() {
  const [step, setStep] = useState(0);
  const [pct,  setPct]  = useState(0);

  useEffect(() => {
    const total = 15000;
    const tick  = total / 100;
    const pctTimer = setInterval(() => {
      setPct(p => { if (p >= 99) { clearInterval(pctTimer); return 99; } return p + 1; });
    }, tick);
    const stepTimer = setInterval(() => {
      setStep(s => (s + 1) % LOADER_STEPS.length);
    }, total / LOADER_STEPS.length);
    return () => { clearInterval(pctTimer); clearInterval(stepTimer); };
  }, []);

  return (
    <div className="exec-loader">
      <div className="el-bar-wrap">
        <div className="el-bar-fill" style={{ width: `${pct}%` }} />
      </div>
      <div className="el-row">
        <span className="el-step">{LOADER_STEPS[step]}</span>
        <span className="el-pct">{pct}%</span>
      </div>
    </div>
  );
}

/* ── Golden Set Panel ──────────────────────────────────────────────── */
const STATUSES = ["COMPLIANT", "NON_COMPLIANT", "EXCLUDED", "NOT_IN_POPULATION"];

function GoldenSetPanel({ parse }) {
  const [cases, setCases]     = useState([
    { member_id: "", expected_status: "COMPLIANT", note: "" }
  ]);
  const [running, setRunning] = useState(false);
  const [result, setResult]   = useState(null);
  const [error, setError]     = useState(null);

  const addCase = () =>
    setCases(c => [...c, { member_id: "", expected_status: "COMPLIANT", note: "" }]);

  const removeCase = (i) =>
    setCases(c => c.filter((_, idx) => idx !== i));

  const updateCase = (i, field, val) =>
    setCases(c => c.map((x, idx) => idx === i ? { ...x, [field]: val } : x));

  const run = async () => {
    const cfg = parse();
    if (!cfg) { setError("Invalid JSON in spec editor."); return; }
    const validCases = cases.filter(c => c.member_id.trim());
    if (!validCases.length) { setError("Add at least one test case."); return; }
    setRunning(true); setResult(null); setError(null);
    try {
      const r = await api.goldenTest({ config: cfg, cases: validCases });
      setResult(r);
    } catch { setError("Test run failed. Check spec and member IDs."); }
    setRunning(false);
  };

  return (
    <div className="gs-panel">
      <div className="gs-header">
        <div className="gs-title">Golden Set Test Cases</div>
        <p className="gs-desc">
          Define hand-verified members with expected statuses.
          Run the test to confirm your spec produces the correct result for each case.
          All cases must pass before a spec is considered production-ready.
        </p>
      </div>

      {/* case table */}
      <table className="gs-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Member ID</th>
            <th>Expected Status</th>
            <th>Note (optional)</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {cases.map((c, i) => (
            <tr key={i}>
              <td className="gs-num">{i + 1}</td>
              <td>
                <input className="gs-input" placeholder="e.g. M003"
                  value={c.member_id}
                  onChange={e => updateCase(i, "member_id", e.target.value)} />
              </td>
              <td>
                <select className="gs-select"
                  value={c.expected_status}
                  onChange={e => updateCase(i, "expected_status", e.target.value)}>
                  {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </td>
              <td>
                <input className="gs-input gs-note" placeholder="Why this member?"
                  value={c.note}
                  onChange={e => updateCase(i, "note", e.target.value)} />
              </td>
              <td>
                <button className="gs-remove" onClick={() => removeCase(i)}
                  disabled={cases.length === 1}>✕</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="gs-actions">
        <button className="gs-add-btn" onClick={addCase}>+ Add Case</button>
        <button className="gs-run-btn" onClick={run} disabled={running}>
          {running ? "Running…" : "Run Golden Set"}
        </button>
      </div>

      {error && <div className="gs-error">{error}</div>}

      {/* results */}
      {result && (
        <div className="gs-results">
          <div className={`gs-overall ${result.overall_passed ? "gs-pass" : "gs-fail"}`}>
            {result.overall_passed
              ? `All ${result.total} test cases passed`
              : `${result.failed} of ${result.total} test cases failed`
            }
          </div>
          <table className="gs-table gs-result-table">
            <thead>
              <tr><th>Member</th><th>Expected</th><th>Actual</th><th>Result</th><th>Note</th></tr>
            </thead>
            <tbody>
              {result.results.map((r, i) => (
                <tr key={i} className={r.passed ? "gs-row-pass" : "gs-row-fail"}>
                  <td className="mono">{r.member_id}</td>
                  <td><span className="gs-status">{r.expected_status}</span></td>
                  <td><span className={`gs-status ${r.passed ? "gs-s-pass" : "gs-s-fail"}`}>
                    {r.actual_status || r.error || "—"}
                  </span></td>
                  <td>
                    <span className={`gs-badge ${r.passed ? "gs-badge-pass" : "gs-badge-fail"}`}>
                      {r.passed ? "PASS" : "FAIL"}
                    </span>
                  </td>
                  <td className="gs-note-cell">{r.note || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ── Spec Manager (merged Edit + Execute) ──────────────────────────── */
function SpecManager({ onDone }) {
  const [specs, setSpecs]         = useState([]);
  const [sel, setSel]             = useState(null);
  const [text, setText]           = useState("");
  const [original, setOriginal]   = useState("");
  const [saveResult, setSaveResult] = useState(null);
  const [dirty, setDirty]         = useState(false);
  const [mode, setMode]           = useState("edit");   // "edit" | "execute"

  // execute state
  const [scope, setScope]         = useState("all");
  const [memberId, setMemberId]   = useState("");
  const [sampleSize, setSampleSize] = useState(10);
  const [running, setRunning]     = useState(false);
  const [execResult, setExecResult] = useState(null);
  const [execError, setExecError] = useState(null);

  const loadList = () => api.listSpecs().then(list => {
    setSpecs(list);
    if (!sel && list.length) pickExisting(list[0].measure_id);
  });

  useEffect(() => { loadList(); }, []);

  const pickExisting = (id) => {
    api.getSpec(id).then(cfg => {
      const s = JSON.stringify(cfg, null, 2);
      setSel(id); setText(s); setOriginal(s); setDirty(false);
      setSaveResult(null); setExecResult(null); setExecError(null);
    });
  };

  const pickNew = () => {
    setSel("new"); setText(NEW_TEMPLATE); setOriginal(NEW_TEMPLATE);
    setDirty(false); setSaveResult(null); setExecResult(null);
  };

  const parse = () => {
    try { return JSON.parse(text); }
    catch (e) { setSaveResult({ error: "Invalid JSON: " + e.message }); return null; }
  };

  const validate = async () => { const c = parse(); if (c) setSaveResult(await api.validateSpec(c)); };

  const save = async () => {
    const c = parse(); if (!c) return;
    const r = await api.uploadSpec(c);
    setSaveResult(r);
    if (r.valid) {
      setOriginal(text); setDirty(false);
      loadList(); onDone();
      if (sel === "new") setSel(r.measure_id);
    }
  };

  const execute = async () => {
    const c = parse(); if (!c) return;
    setRunning(true); setExecResult(null); setExecError(null);
    try {
      const r = await api.executeSpec({
        config: c, scope,
        member_id:   scope === "member" ? memberId : undefined,
        sample_size: scope === "sample" ? sampleSize : undefined,
      });
      setExecResult(r);
    } catch (e) {
      setExecError("Execution failed. Check the spec and try again.");
    }
    setRunning(false);
  };

  const isNew   = sel === "new";
  const selMeta = specs.find(s => s.measure_id === sel);

  return (
    <div className="sr-page">

      {/* ── sidebar ── */}
      <div className="sr-sidebar">
        <button className="sr-new-btn" onClick={pickNew}>+ New Spec</button>
        <div className="sr-sidebar-title">Loaded Specs</div>
        {specs.map(s => (
          <div key={s.measure_id}
            className={`sr-spec-item ${sel === s.measure_id ? "active" : ""}`}
            onClick={() => pickExisting(s.measure_id)}>
            <div className="sr-spec-id">{s.measure_id}</div>
            <div className="sr-spec-name">{s.measure_name}</div>
            <div className="sr-spec-ver">{s.version}</div>
          </div>
        ))}
      </div>

      {/* ── main panel ── */}
      <div className="sr-main">

        {/* mode tabs */}
        <div className="sr-mode-tabs">
          <div className="sr-spec-label">
            {isNew
              ? <span className="sr-new-tag">New Spec</span>
              : <><span className="mono sr-mid">{selMeta?.measure_id}</span>
                  <span className="sr-mname">{selMeta?.measure_name}</span>
                  <span className="sr-ver">{selMeta?.version}</span></>
            }
          </div>
          <div className="sr-tabs">
            <button className={mode === "edit"    ? "sr-tab-on" : "sr-tab"} onClick={() => setMode("edit")}>Edit Spec</button>
            <button className={mode === "execute" ? "sr-tab-on" : "sr-tab"} onClick={() => setMode("execute")}>Execute</button>
            {/* <button className={mode === "golden"  ? "sr-tab-on" : "sr-tab"} onClick={() => setMode("golden")}>Golden Set</button> */}
          </div>
        </div>

        {/* ── EDIT mode ── */}
        {mode === "edit" && (
          <>
            <div className="sr-edit-actions">
              {dirty && <span className="sr-dirty">Unsaved changes</span>}
              <button className="sr-btn sr-btn-ghost"   onClick={() => { setText(original); setDirty(false); setSaveResult(null); }} disabled={!dirty}>Reset</button>
              <button className="sr-btn sr-btn-outline" onClick={validate}>Validate</button>
              <button className="sr-btn sr-btn-primary" onClick={save}>{isNew ? "Save & Run" : "Update & Run"}</button>
            </div>
            <textarea className="sr-textarea" value={text}
              onChange={e => { setText(e.target.value); setDirty(e.target.value !== original); setSaveResult(null); }}
              spellCheck={false} />
            {saveResult && (
              <div className={`sr-result ${saveResult.valid || saveResult.summary ? "ok" : "bad"}`}>
                {saveResult.error
                  ? saveResult.error
                  : saveResult.valid
                    ? `Spec is valid${saveResult.summary ? ` — compliance rate: ${saveResult.summary.compliance_rate}%` : ""}`
                    : (saveResult.errors?.join("\n") || JSON.stringify(saveResult, null, 2))
                }
              </div>
            )}
          </>
        )}

        {/* ── EXECUTE mode ── */}
        {mode === "execute" && (
          <div className="exec-panel">

            {/* scope selector */}
            <div className="exec-scope">
              <div className="exec-scope-title">Execution Scope</div>
              <div className="exec-scope-options">
                {[
                  { value: "all",    label: "Entire Population",  desc: "Run against all loaded members" },
                  { value: "sample", label: "Random Sample",      desc: "Run against a random subset" },
                  { value: "member", label: "Single Member",      desc: "Run against one specific member" },
                ].map(o => (
                  <label key={o.value} className={`exec-scope-opt ${scope === o.value ? "selected" : ""}`}>
                    <input type="radio" name="scope" value={o.value}
                      checked={scope === o.value} onChange={() => setScope(o.value)} />
                    <div>
                      <div className="exec-opt-label">{o.label}</div>
                      <div className="exec-opt-desc">{o.desc}</div>
                    </div>
                  </label>
                ))}
              </div>

              {/* scope-specific inputs */}
              {scope === "sample" && (
                <div className="exec-input-row">
                  <label className="exec-input-label">Sample size</label>
                  <input type="number" className="exec-input" min={1} max={50}
                    value={sampleSize} onChange={e => setSampleSize(+e.target.value)} />
                </div>
              )}
              {scope === "member" && (
                <div className="exec-input-row">
                  <label className="exec-input-label">Member ID</label>
                  <input type="text" className="exec-input" placeholder="e.g. M001"
                    value={memberId} onChange={e => setMemberId(e.target.value)} />
                </div>
              )}

              <button className="exec-run-btn" onClick={execute} disabled={running}>
                {running ? "Running…" : "Execute Spec"}
              </button>
              {execError && <div className="exec-error">{execError}</div>}
              {running && <ExecLoader />}
            </div>

            {/* results */}
            {execResult && <ExecResults results={execResult.results} summary={execResult.summary} />}
          </div>
        )}

        {/* ── GOLDEN SET mode ── */}
        {mode === "golden" && (
          <GoldenSetPanel getText={() => text} parse={() => {
            try { return JSON.parse(text); }
            catch { return null; }
          }} />
        )}
      </div>
    </div>
  );
}
